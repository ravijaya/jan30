import paramiko
import pdb

"""https://pastebin.com/raw/eCfzXFdL"""

class CustomSSHClient:
    """ssh client"""

    def __init__(self, host, port, user, pwd):
        self.host = host
        self.port = port
        self.user = user
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(self.host, self.port, self.user, pwd)

    def sftp_upload(self, file_name):
        ftp = self.ssh.open_sftp()
        ftp.put(file_name, file_name)
        ftp.close()
        print(file_name, ': done uploading')

    def check_output(self, cmd):
        stdin, stdout, stderr = self.ssh.exec_command(cmd)
        payload = stdout.read().decode('ascii', 123)
        return payload if payload else stderr.read().decode('ascii')

    def __del__(self):
        self.ssh.close()


if __name__ == '__main__':
    from traceback import print_tb
    from sys import exc_info
    try:
        ssh = CustomSSHClient('ravijaya.info', 22, 'training', 'training')
        op = ssh.check_output('ls -ltr')
        print(op)
    except TypeError as err:
        #print(exc_info())
        print_tb(exc_info()[-1])
        #print(err)

"""https://pastebin.com/raw/ynV1Qv0T"""