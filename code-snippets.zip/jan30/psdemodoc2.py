"""demo for the doctest"""
# https://pastebin.com/raw/3NH24FwK
def power(x, n):
    return x ** n


if __name__ == '__main__':
    import doctest
    doctest.testfile('test.txt')