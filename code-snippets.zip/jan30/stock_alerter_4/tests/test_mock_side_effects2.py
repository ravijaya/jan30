from unittest import mock



# mock a function that has to return different values each time it is called, as shown in the following:
m = mock.Mock()
m.side_effect = [1, 2, 3]
print(m())
print(m())
print(m())
# print(m())