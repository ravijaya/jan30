from unittest import mock



# We can use the same procedure to set the return value of a method in a mock object as follows:
rule = mock.MagicMock()
rule.matches = mock.Mock(return_value=True)
print(rule.matches())


# alternative

rule = mock.MagicMock()
rule.matches.return_value = True
print(rule.matches())