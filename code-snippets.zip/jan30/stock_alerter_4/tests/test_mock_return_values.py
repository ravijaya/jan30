from unittest import mock



matches = mock.Mock(return_value=True)
print(matches())
print(matches(4))
print(matches(1, 2, 3))