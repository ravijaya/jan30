import unittest
from unittest import mock
from ..event import Event


class EventTest(unittest.TestCase):
    def test_a_listener_is_notified_when_an_event_is_raised(self):
        listener = mock.Mock()
        event = Event()
        event.connect(listener)
        event.fire()
        self.assertTrue(listener.called)

    def test_a_listener_is_passed_right_parameters(self):
        listener = mock.Mock()
        event = Event()
        event.connect(listener)
        event.fire(5, shape="square")
        listener.assert_called_with(5, shape="square")

    def test_a_listener_is_passed_right_parameters_2(self):
        listener = mock.Mock()
        event = Event()
        event.connect(listener)
        event.fire(5, shape="square")
        listener.assert_has_calls([mock.call(5, shape="square")])

if __name__ == '__main__':
    unittest.main()

"""
Mock objects have the following four assertions available out of the box:
• assert_called_with : This method asserts that the last call was made with
• assert_called_once_with : This assertion checks that the method was
called exactly once and was with the given parameters
• assert_any_call : This checks that the given call was made at some point
during the execution
• assert_has_calls : This assertion checks that a list of calls occurred

"""