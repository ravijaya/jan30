from unittest import mock



m = mock.Mock()
m.side_effect = Exception()
m()