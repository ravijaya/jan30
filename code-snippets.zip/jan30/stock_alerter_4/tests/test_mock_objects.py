from unittest import mock


class PrintAction:
    def run(self, *description):
        print("{0} was executed".format(description))


if __name__ == '__main__':
    p = PrintAction()

    mock_1 = mock.Mock()
    print(mock_1.execute("sample alert"))

    mock_2 = mock.Mock(p)
    # mock_2.name = 'pip'
    print(mock_2.run(1, 2, 3))
    mock_2.run.assert_called_with(1, 2, 3, 4)

    # mock_2.execute("sample alert")
