import unittest
from datetime import datetime

from stock_alerter_2_1.stock import Stock


# Arrange-Act-Assert

class StockTest(unittest.TestCase):
    def test_stock_update(self):
        """
        An update should set the price on the stock object
        We will be using the `datetime` module for the timestamp
        """
        goog = Stock("GOOG")  # Arrange
        goog.update(datetime(2014, 2, 12), price=10)  # ACT
        self.assertEqual(10, goog.price)  # Assert


if __name__ == '__main__':
    unittest.main()
