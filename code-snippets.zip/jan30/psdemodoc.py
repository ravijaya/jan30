"""demo for the doctest"""
# https://pastebin.com/raw/3NH24FwK
def power(x, n):
    """
    >>> from psdemodoc import power
    >>>
    >>> power(3, 2)
    9

    >>> power(3, 'peter')
    Traceback (most recent call last):
    ...
    TypeError: unsupported operand type(s) for ** or pow(): 'int' and 'str'

    >>>
    >>>
    >>> power(3)
    Traceback (most recent call last):
      File "<stdin>", line 1, in <module>
    TypeError: power() missing 1 required positional argument: 'n'

    """
    return x ** n


if __name__ == '__main__':
    import doctest
    doctest.testmod()