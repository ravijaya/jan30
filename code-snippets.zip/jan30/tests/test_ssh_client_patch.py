import unittest
from unittest import mock
import pssshclient


@mock.patch('pssshclient.CustomSSHClient')
class SSHClientTest(unittest.TestCase):
    def test_ssh_client_2(self, mock_ssh):
        mock_ssh.sftp_dl('src', 'dest')
        mock_ssh.sftp_dl.assert_called_with('src', 'dest')

    def test_ssh_client_mock(self, mock_ssh):
        mock_ssh.check_output.return_value = 'training\n'
        op = mock_ssh.check_output('whoami')
        mock_ssh.check_output.assert_called_with('whoami')
        self.assertEqual(op, 'training\n')


if __name__ == '__main__':
    unittest.main()
