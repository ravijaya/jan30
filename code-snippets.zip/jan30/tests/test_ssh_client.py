import unittest
from unittest import mock
from pssshclient import CustomSSHClient



class SSHClientTest(unittest.TestCase):
    def test_ssh_client(self):
        ssh = CustomSSHClient('ravijaya.info', 22, 'training', 'training')
        op = ssh.check_output('whoami')
        self.assertEqual(op, 'training\n')

    def test_ssh_client_mock(self):
        ssh_mock = mock.Mock(spec=CustomSSHClient)
        ssh_mock.check_output.return_value = 'training\n'
        op = ssh_mock.check_output('whoami')
        ssh_mock.check_output.assert_called_with('whoami')
        self.assertEqual(op, 'training\n')


if __name__ == '__main__':
    unittest.main()