from datetime import timedelta


class Stock:
    def __init__(self, symbol):
        self.symbol = symbol
        self.price_history = []

    @property
    def price(self):
        return self.price_history[-1] if self.price_history else None

    def update(self, timestamp, price):
        if price < 0:
            raise ValueError("price should not be negative")
        self.price_history.append(price)

    def is_increasing_trend(self):
        return self.price_history[-3] < self.price_history[-2] < self.price_history[-1]

    def get_crossover_signal(self, on_date):
        LONG_TERM_TIMESPAN = 10
        SHORT_TERM_TIMESPAN = 5

        closing_price_list = []
        NUM_DAYS = self.LONG_TERM_TIMESPAN + 1

        for i in range(NUM_DAYS):
            chk = on_date.date() - timedelta(i)

            for price_event in reversed(self.price_history):
                if price_event.timestamp.date() > chk:
                    pass

                if price_event.timestamp.date() == chk:
                    closing_price_list.insert(0, price_event)
                    break

                if price_event.timestamp.date() < chk:
                    closing_price_list.insert(0, price_event)
                    break
                    # Return NEUTRAL signal

            if len(closing_price_list) < 11:
                return 0

            # BUY signal
            if sum([update.price for update in closing_price_list[-11:-1]]) / 10 > sum(
                    [update.price for update in closing_price_list[-6:-1]]) / 5 \
                    and sum([update.price for update in closing_price_list[-10:]]) / 10 < sum(
                [update.price for update in closing_price_list[-5:]]) / 5:
                return 1
            # BUY signal
            if sum([update.price for update in closing_price_list[-11:-1]]) / 10 < sum(
                    [update.price for update in closing_price_list[-6:-1]]) / 5 \
                    and sum([update.price for update in closing_price_list[-10:]]) / 10 > sum(
                [update.price for update in closing_price_list[-5:]]) / 5:
                return -1
            # NEUTRAL signal
            return 0
