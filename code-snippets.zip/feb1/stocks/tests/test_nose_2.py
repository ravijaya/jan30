from stocks.stock import Stock
"""https://pastebin.com/raw/duEj50BL"""
# with fixtures

def setup_test():
    global goog
    goog = Stock("GOOG")
    print(goog)


def teardown_test():
    global goog
    print('clean-up')
    goog = None


def test_price_of_a_new_stock_class_should_be_None():
    assert goog.price is None, "Price of a new stock should be None"


test_price_of_a_new_stock_class_should_be_None.setup = setup_test
test_price_of_a_new_stock_class_should_be_None.teardown = teardown_test
