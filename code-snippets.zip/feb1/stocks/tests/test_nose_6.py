from stocks.stock import Stock
import unittest
from datetime import datetime
from nose2.tools import such  #DSL
from stocks.tests.test_nose_4 import given_a_series_of_prices

"""
Layers
~~~~~~~
If we look at the tests for our Stock class, we see that we have created three test
classes: StockTest , StockTrendTest , and StockCrossOverSignalTest . All the
three classes have some repetition in the setUp code, as shown in the following:

class StockTest(unittest.TestCase):
    def setUp(self):
        self.goog = Stock("GOOG")

class StockCrossOverSignalTest(unittest.TestCase):
    def setUp(self):
        self.goog = Stock("GOOG")

What if we could share part of the setup between them?
    nose2 has another way to write tests called Layers. Layers allow us to organize our
    tests hierarchically. 
    
    https://pastebin.com/raw/tcT7BnWi
"""
from nose2.tools.params import params

with such.A("Stock class") as it:  # top layer
    @it.has_setup
    def setup():
        it.goog = Stock("GOOG")


    with it.having("a price method"):  # help to define sub level
        @it.has_setup
        def setup():
            it.goog.update(datetime(2014, 2, 12), price=10)


        @it.should("return the price")
        def test(case):
            assert it.goog.price == 10


        @it.should("return the latest price")
        def test(case):  # test
            it.goog.update(datetime(2014, 2, 11), price=15)
            assert it.goog.price == 10

    with it.having("a trend method"):
        @it.should("return True if last three updates were increasing ")
        @params(
            (datetime(2014, 2, 11), 12),
            (datetime(2014, 2, 12), 13),
            (datetime(2014, 2, 13), 14),
        )
        def ravi(case, ts, p):
            it.goog.update(ts, p)
            assert it.goog.is_increasing_trend()

it.createTests(globals())

"""
# plugins 
nose2 --plugin nose2.plugins.layers
nose2 --plugin nose2.plugins.layers --layer-reporter -v
nose2 --plugin nose2.plugins.doctests --with-doctest
nose2 --plugin nose2.plugins.junitxml --junit-xml

https://pastebin.com/raw/BFwea9EU
"""