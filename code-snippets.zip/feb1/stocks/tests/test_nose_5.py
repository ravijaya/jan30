from stocks.stock import Stock
import unittest
from datetime import datetime
from nose2.tools.params import params
from stocks.tests.test_nose_4 import given_a_series_of_prices

""" https://pastebin.com/raw/gFt66EJP """

"""
Generated tests
~~~~~~~~~~~~~~~

Apart from parameterized tests, nose2 also supports generated tests. This is
similar to parameterized tests. 

The difference is that parameterized tests have all the inputs hardcoded while writing the test, 
whereas they can be created at run time in generated tests.
"""
"""https://pastebin.com/raw/gK5eZGWB"""

# The following is an example to clarify:
from random import choice

def test_trend_with_all_consecutive_values_upto_100():
    output = [True, False]
    for i in range(3):
        yield stock_trends_with_consecutive_prices, [i, i + 1, i + 2], choice(output)


def stock_trends_with_consecutive_prices(prices, expected_output):
    goog = Stock("GOOG")
    given_a_series_of_prices(goog, prices)
    #assert goog.is_increasing_trend() == expected_output
    return goog.is_increasing_trend()


if __name__ == '__main__':
    for func, price, outcome in test_trend_with_all_consecutive_values_upto_100():
        print(func(price, outcome))