from stocks.stock import Stock
import unittest


class StockTest(unittest.TestCase):
    """unittest"""
    def setUp(self):
        self.goog = Stock("GOOG")

    def test_price_of_a_new_stock_class_should_be_None_unittest(self):
        self.assertIsNone(self.goog.price)


def test_price_of_a_new_stock_class_should_be_None():
    goog = Stock("GOOG")
    assert goog.price is None, 'price is not None'
