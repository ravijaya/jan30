# Pattern – using attributes
# The nose2 test runner has a useful attrib plugin that allows us to
# set attributes on test cases and select tests that match particular attributes.

from stocks.stock import Stock
import unittest
from datetime import datetime



def test_stock_update():
    goog = Stock("GOOG")
    goog.update(datetime(2014, 2, 12), price=10)
    assert 10 == goog.price


test_stock_update.integration = True
test_stock_update.python = ["2.6", "3.4"]

"""
nose2 --plugin=nose2.plugins.attrib -A "integration"
nose2 --plugin=nose2.plugins.attrib -A "python=2.6"
nose2 --plugin=nose2.plugins.attrib -E "integration and '2.6' in python"
"""