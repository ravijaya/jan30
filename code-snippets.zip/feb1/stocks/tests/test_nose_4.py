from stocks.stock import Stock
from datetime import datetime
from nose2.tools.params import params

"""
https://pastebin.com/raw/Sme2dA2E

Parameterized tests
nose2 also supports parameterized tests. Also called data-driven tests, these are
nothing but running the same test with different combinations of data.
"""


# By parameterizing the test, we can write it like the following:

def given_a_series_of_prices(stock, prices):
    timestamps = [datetime(2014, 2, 10), datetime(2014, 2, 11),
                  datetime(2014, 2, 12), datetime(2014, 2, 13)]

    for timestamp, price in zip(timestamps, prices):
        stock.update(timestamp, price)


@params(
    ([8, 10, 12], True),
    ([8, 12, 14], False),
    ([8, 10, 10], False)
)
def test_stock_trends(prices, expected_output):
    goog = Stock("GOOG")
    given_a_series_of_prices(goog, prices)
    assert goog.is_increasing_trend() == expected_output

