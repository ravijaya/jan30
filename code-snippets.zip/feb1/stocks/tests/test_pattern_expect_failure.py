#Sometimes, we have tests that are failing, but, for whatever reason,
#we don't want to fix it yet. It could be that we found a bug and wrote a
# failing test that demonstrates the bug (a very good practice),

import unittest


def power(x, y):
    return x ** n


class PatternExpectFailureTest(unittest.TestCase):
    @unittest.expectedFailure
    def test_expect_failure(self):
        power(5)


if __name__ == '__main__':
    unittest.main()
