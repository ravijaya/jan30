#!/usr/bin/env python3
# encoding: utf-8
#

#
"""Run tests for another module we import.
"""

#end_pymotw_header
import doctest_simple

if __name__ == '__main__':
    import doctest
    doctest.testmod(doctest_simple)
