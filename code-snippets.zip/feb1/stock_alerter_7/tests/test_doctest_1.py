from stock_alerter_7.stock import Stock


def price():
    """Returns the current price of the Stock
    >>> from datetime import datetime
    >>> from stock_alerter_7.stock import Stock
    >>> stock = Stock("GOOG")
    >>> stock.update(datetime(2011, 10, 3), 10)
    >>> stock.price
    10
    """
    try:
        stock = Stock("GOOG")
        return stock.history[-1].value
    except IndexError:
        return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()


# python -m  stock_alerter_7.tests.test_doctest_1  -v