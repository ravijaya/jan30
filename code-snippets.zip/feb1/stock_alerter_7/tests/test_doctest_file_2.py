if __name__ == "__main__":
    import doctest
    doctest.testfile("../readme.txt")