# Requirements

## Structure
1. Written in Python
2. Use only python packages and libraries that come with a relatively standard python installation.
3. All contained in one python file

## Functionality
1. Implement all original Markdown functionality. 



