markdown.py
===========

Yet another python implementation of markdown

## Status
Stub implementation here.  
It doesn't really do anything but spit out the input.  
But it will work to start setting up testing frameworks.

Initial doctest here.

## Follow along
This project is part of a demo project on [Python Testing](http://pythontesting.net).   
You can follow it's progress in the [Markdown category](http://pythontesting.net/category/markdown/).

## Requirements
Requirements moved to [Requirements.md](https://github.com/variedthoughts/markdown.py/blob/master/Requirements.md)

