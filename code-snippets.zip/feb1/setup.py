from distutils.core import setup

setup(name='stocks',
      version='1.1.1',
      packages=['stocks', 'stocks.tests'],
      author='jaya')
